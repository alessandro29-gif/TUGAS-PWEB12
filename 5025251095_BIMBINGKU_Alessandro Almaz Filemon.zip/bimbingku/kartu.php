<?php
require_once "auth.php";
wajib_login();
$role = $_SESSION["role"];
if ($role == "siswa") {
    $s = satu("SELECT s.*, k.nama_kelas, c.nama_cabang FROM siswa s JOIN kelas k ON k.id_kelas=s.id_kelas JOIN cabang c ON c.id_cabang=s.id_cabang WHERE s.id_user=?", "i", [$_SESSION["id_user"]]);
} elseif (in_array($role, ["admin", "admin_cabang"])) {
    $s = satu("SELECT s.*, k.nama_kelas, c.nama_cabang FROM siswa s JOIN kelas k ON k.id_kelas=s.id_kelas JOIN cabang c ON c.id_cabang=s.id_cabang WHERE s.id_siswa=?", "i", [(int)($_GET["id"] ?? 0)]);
    if ($s && id_cabang_batas() && $s["id_cabang"] != id_cabang_batas()) { $s = null; }
} else { header("Location: index.php"); exit; }
if (!$s || $s["status"] != "Diterima") {
    $_SESSION["pesan"] = "Kartu member hanya tersedia untuk siswa yang sudah diterima.";
    $_SESSION["pesan_galat"] = 1;
    header("Location: index.php"); exit;
}
$f = url_foto($s["foto"]);
$halaman = "kartu";
$judul_hero = "Kartu Member";
$teks_hero = "Cetak langsung dari browser (Ctrl + P).";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-member">
<div class="atas"><span>BIMBINGKU</span><small><?php echo e($s["nama_cabang"]); ?></small></div>
<div class="isi">
<?php if($f){ ?><img class="foto" src="<?php echo $f; ?>" alt="Pas foto <?php echo e($s["nama"]); ?>"><?php } else { ?><div class="foto"></div><?php } ?>
<div>
<h3><?php echo e($s["nama"]); ?></h3>
<p><strong>Kelas:</strong> <?php echo e($s["nama_kelas"]); ?></p>
<p><strong>Lahir:</strong> <?php echo tgl($s["tgl_lahir"]); ?></p>
<p><strong>Bergabung:</strong> <?php echo tgl($s["tgl_daftar"]); ?></p>
</div>
</div>
<div class="bawah"><?php echo e($s["no_kartu"]); ?></div>
</div>
<p class="tidak-cetak" style="text-align:center;margin:24px auto 0"><button type="button" class="btn-utama" onclick="window.print()">Cetak Kartu</button></p>
</div>
</section>
<?php include "footer.php"; ?>
