<?php
require_once "auth.php";
wajib_login(["pengajar", "siswa"]);
$role = $_SESSION["role"];

if ($role == "pengajar") {
    $ip = id_pengajar_saya();
    $daftar = semua("SELECT * FROM kelas WHERE id_pengajar=? ORDER BY nama_kelas", "i", [$ip]);
    $idk = (int)($_GET["kelas"] ?? ($_POST["id_kelas"] ?? ($daftar[0]["id_kelas"] ?? 0)));
    $kelas = satu("SELECT * FROM kelas WHERE id_kelas=? AND id_pengajar=?", "ii", [$idk, $ip]);

    if ($kelas && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
        $salah = false;
        foreach (($_POST["tugas"] ?? []) as $ids => $t) {
            $ids = (int)$ids;
            $k = $_POST["kuis"][$ids] ?? ""; $u = $_POST["ujian"][$ids] ?? "";
            if ($t === "" && $k === "" && $u === "") { continue; }
            foreach ([$t, $k, $u] as $x) { if (!ctype_digit((string)$x) || (int)$x > 100) { $salah = true; continue 2; } }
            if (!satu("SELECT id_siswa FROM siswa WHERE id_siswa=? AND id_kelas=? AND status='Diterima'", "ii", [$ids, $idk])) { continue; }
            $akhir = round($t * 0.3 + $k * 0.3 + $u * 0.4, 2);
            $cat = trim($_POST["catatan"][$ids] ?? "");
            q("INSERT INTO nilai (id_kelas, id_siswa, nilai_tugas, nilai_kuis, nilai_ujian, nilai_akhir, catatan) VALUES (?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE nilai_tugas=VALUES(nilai_tugas), nilai_kuis=VALUES(nilai_kuis), nilai_ujian=VALUES(nilai_ujian), nilai_akhir=VALUES(nilai_akhir), catatan=VALUES(catatan)",
              "iiiiids", [$idk, $ids, (int)$t, (int)$k, (int)$u, $akhir, $cat]);
        }
        $_SESSION["pesan"] = $salah ? "Sebagian nilai tidak disimpan: harus angka bulat 0-100." : "Nilai berhasil disimpan.";
        if ($salah) { $_SESSION["pesan_galat"] = 1; }
        header("Location: nilai.php?kelas=$idk"); exit;
    }
    $siswa = $kelas ? semua("SELECT s.id_siswa, s.nama, n.nilai_tugas, n.nilai_kuis, n.nilai_ujian, n.nilai_akhir, n.catatan FROM siswa s LEFT JOIN nilai n ON n.id_siswa=s.id_siswa AND n.id_kelas=s.id_kelas WHERE s.id_kelas=? AND s.status='Diterima' ORDER BY s.nama", "i", [$idk]) : [];
} else {
    $data = semua("SELECT n.*, k.nama_kelas FROM nilai n JOIN kelas k ON k.id_kelas=n.id_kelas WHERE n.id_siswa=? ORDER BY k.nama_kelas", "i", [id_siswa_saya()]);
}

$halaman = "nilai";
$judul_hero = $role == "pengajar" ? "Input Nilai" : "Nilai Saya";
$teks_hero = $role == "pengajar" ? "Nilai akhir = tugas 30% + kuis 30% + ujian 40%." : "Nilai tugas, kuis, ujian, dan nilai akhir.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<?php if ($role == "pengajar") { ?>
<form method="get" class="alat-bar">
<select class="form-control saring" name="kelas" aria-label="Pilih kelas">
<?php foreach($daftar as $k){ ?><option value="<?php echo $k["id_kelas"]; ?>"<?php echo $idk == $k["id_kelas"] ? " selected" : ""; ?>><?php echo e($k["nama_kelas"]); ?></option><?php } ?>
</select>
<button type="submit" class="btn-sekunder">Tampilkan</button>
</form>
<?php if (!$kelas) { ?><p>Kamu belum mengampu kelas.</p><?php } else { ?>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id_kelas" value="<?php echo $idk; ?>">
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:820px">
<thead><tr><th>Siswa</th><th>Tugas</th><th>Kuis</th><th>Ujian</th><th>Akhir</th><th>Catatan</th></tr></thead>
<tbody>
<?php foreach ($siswa as $s) { $i = $s["id_siswa"]; ?>
<tr>
<td class="nama"><?php echo e($s["nama"]); ?></td>
<?php foreach(["tugas" => "nilai_tugas", "kuis" => "nilai_kuis", "ujian" => "nilai_ujian"] as $nm => $kol){ ?>
<td><input type="number" min="0" max="100" class="form-control" name="<?php echo $nm; ?>[<?php echo $i; ?>]" aria-label="<?php echo ucfirst($nm); ?> <?php echo e($s["nama"]); ?>" value="<?php echo isset($s[$kol]) ? (int)$s[$kol] : ""; ?>" style="width:84px;height:36px;border-width:2px;padding:2px 8px"></td>
<?php } ?>
<td><strong><?php echo isset($s["nilai_akhir"]) ? e($s["nilai_akhir"]) : "-"; ?></strong></td>
<td><input class="form-control" name="catatan[<?php echo $i; ?>]" aria-label="Catatan <?php echo e($s["nama"]); ?>" value="<?php echo e($s["catatan"] ?? ""); ?>" style="height:36px;border-width:2px;padding:2px 10px"></td>
</tr>
<?php } ?>
<?php if (!$siswa) { ?><tr><td colspan="6" class="kosong">Belum ada siswa diterima di kelas ini.</td></tr><?php } ?>
</tbody>
</table>
</div>
<p class="pesan-error" id="err"></p>
<?php if ($siswa) { ?><p style="margin-top:20px"><button type="submit" name="simpan" value="1" class="btn-utama">Simpan Nilai</button></p><?php } ?>
</form>
<?php } ?>
<?php } else { ?>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:640px">
<thead><tr><th>Kelas</th><th>Tugas</th><th>Kuis</th><th>Ujian</th><th>Akhir</th><th>Catatan</th></tr></thead>
<tbody>
<?php foreach ($data as $n) { ?><tr><td class="nama"><?php echo e($n["nama_kelas"]); ?></td><td><?php echo $n["nilai_tugas"]; ?></td><td><?php echo $n["nilai_kuis"]; ?></td><td><?php echo $n["nilai_ujian"]; ?></td><td><strong><?php echo e($n["nilai_akhir"]); ?></strong></td><td><?php echo e($n["catatan"]); ?></td></tr><?php } ?>
<?php if (!$data) { ?><tr><td colspan="6" class="kosong">Belum ada nilai.</td></tr><?php } ?>
</tbody>
</table>
</div>
<?php } ?>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
var el = f.querySelectorAll("input[type=number]");
for(var i = 0; i < el.length; i++){
var v = el[i].value;
if(v !== "" && (!/^\d+$/.test(v) || Number(v) > 100)){ err.textContent = "Nilai harus angka bulat 0-100."; el[i].focus(); return false; }
}
return true;
}
</script>
<?php include "footer.php"; ?>
