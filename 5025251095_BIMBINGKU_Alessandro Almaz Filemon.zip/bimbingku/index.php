<?php
require_once "auth.php";
wajib_login();
$role = $_SESSION["role"];
$kartu = []; $grafik = null;

if ($role == "admin" || $role == "admin_cabang") {
    $b = id_cabang_batas();
    $w = $b ? " WHERE id_cabang=$b" : "";
    $wa = $b ? " AND id_cabang=$b" : "";
    $kartu[] = ["Siswa diterima", satu("SELECT COUNT(*) n FROM siswa WHERE status='Diterima'$wa")["n"], ""];
    $kartu[] = ["Menunggu verifikasi", satu("SELECT COUNT(*) n FROM siswa WHERE status='Menunggu'$wa")["n"], "biru"];
    $kartu[] = ["Kelas aktif", satu("SELECT COUNT(*) n FROM kelas WHERE status='aktif'$wa")["n"], "bulan"];
    $kartu[] = ["Pembayaran terverifikasi", rupiah(satu("SELECT COALESCE(SUM(p.jumlah),0) n FROM pembayaran p JOIN kelas k ON k.id_kelas=p.id_kelas WHERE p.status='Diterima'" . ($b ? " AND k.id_cabang=$b" : ""))["n"]), "gelap"];
    $judul_grafik = "Siswa per Kelas";
    $g = semua("SELECT k.nama_kelas, COUNT(s.id_siswa) n FROM kelas k LEFT JOIN siswa s ON s.id_kelas=k.id_kelas AND s.status='Diterima'" . ($b ? " WHERE k.id_cabang=$b" : "") . " GROUP BY k.id_kelas ORDER BY k.nama_kelas");
    $grafik = [array_column($g, "nama_kelas"), array_map("intval", array_column($g, "n"))];
} elseif ($role == "pengajar") {
    $ip = id_pengajar_saya();
    $kartu[] = ["Kelas diampu", satu("SELECT COUNT(*) n FROM kelas WHERE id_pengajar=?", "i", [$ip])["n"], ""];
    $kartu[] = ["Siswa di kelas saya", satu("SELECT COUNT(*) n FROM siswa s JOIN kelas k ON k.id_kelas=s.id_kelas WHERE k.id_pengajar=? AND s.status='Diterima'", "i", [$ip])["n"], "biru"];
    $kartu[] = ["Rata-rata nilai", round(satu("SELECT COALESCE(AVG(n.nilai_akhir),0) a FROM nilai n JOIN kelas k ON k.id_kelas=n.id_kelas WHERE k.id_pengajar=?", "i", [$ip])["a"], 1), "bulan"];
    $h = satu("SELECT COUNT(*) t, COALESCE(SUM(p.status='Hadir'),0) h FROM presensi p JOIN kelas k ON k.id_kelas=p.id_kelas WHERE k.id_pengajar=?", "i", [$ip]);
    $kartu[] = ["Kehadiran siswa", ($h["t"] ? round($h["h"] / $h["t"] * 100) : 0) . "%", "gelap"];
    $judul_grafik = "Nilai Rata-rata per Kelas";
    $g = semua("SELECT k.nama_kelas, COALESCE(AVG(n.nilai_akhir),0) a FROM kelas k LEFT JOIN nilai n ON n.id_kelas=k.id_kelas WHERE k.id_pengajar=? GROUP BY k.id_kelas", "i", [$ip]);
    $grafik = [array_column($g, "nama_kelas"), array_map(function($x){ return round($x, 1); }, array_column($g, "a"))];
} else {
    $is = id_siswa_saya();
    $s = satu("SELECT s.*, k.nama_kelas, k.hari, k.jam FROM siswa s JOIN kelas k ON k.id_kelas=s.id_kelas WHERE s.id_siswa=?", "i", [$is]);
    $h = satu("SELECT COUNT(*) t, COALESCE(SUM(status='Hadir'),0) h FROM presensi WHERE id_siswa=?", "i", [$is]);
    $pay = satu("SELECT status FROM pembayaran WHERE id_siswa=? ORDER BY id_pembayaran DESC LIMIT 1", "i", [$is]);
    $kartu[] = ["Kelas yang diikuti", $s ? e($s["nama_kelas"]) : "-", ""];
    $kartu[] = ["Kehadiran", ($h["t"] ? round($h["h"] / $h["t"] * 100) : 0) . "%", "biru"];
    $kartu[] = ["Rata-rata nilai", round(satu("SELECT COALESCE(AVG(nilai_akhir),0) a FROM nilai WHERE id_siswa=?", "i", [$is])["a"], 1), "bulan"];
    $kartu[] = ["Status pembayaran", $pay ? e($pay["status"]) : "-", "gelap"];
}
$target = $role == "pengajar" ? "Pengajar" : ($role == "siswa" ? "Siswa" : "Semua");
$info = semua("SELECT * FROM pengumuman WHERE target IN ('Semua', ?) ORDER BY id_pengumuman DESC LIMIT 3", "s", [$target]);

$halaman = "index";
$judul_hero = "Dashboard";
$teks_hero = "Halo, " . $_SESSION["nama"] . " (" . nama_role($role) . ").";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="baris-sama">
<?php foreach ($kartu as $k) { ?>
<div class="col-sm-6 col-md-3"><div class="kartu-statistik <?php echo $k[2]; ?>"><div class="nilai"><?php echo $k[1]; ?></div><p class="label"><?php echo $k[0]; ?></p></div></div>
<?php } ?>
</div>
<?php if ($grafik) { ?>
<h2><?php echo $judul_grafik; ?></h2>
<div class="kartu-form" style="margin-bottom:40px"><div class="grafik-kotak"><canvas id="grafik" role="img" aria-label="<?php echo $judul_grafik; ?>"></canvas></div></div>
<?php } ?>
<h2>Pengumuman Terbaru</h2>
<?php foreach ($info as $p) { ?>
<div class="kotak-info"><strong><?php echo e($p["judul"]); ?></strong> <span class="kecil">(<?php echo tgl($p["created_at"]); ?>)</span><br><?php echo e($p["isi"]); ?></div>
<?php } ?>
<?php if (!$info) { ?><p>Belum ada pengumuman.</p><?php } ?>
</div>
</section>
<?php if ($grafik) { ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById("grafik"), {
type: "bar",
data: { labels: <?php echo json_encode($grafik[0]); ?>, datasets: [{ label: "<?php echo $judul_grafik; ?>", data: <?php echo json_encode($grafik[1]); ?>, backgroundColor: "#75CBD1", borderColor: "#0C0D45", borderWidth: 3, borderRadius: 10 }] },
options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }
});
</script>
<?php } ?>
<?php include "footer.php"; ?>
