<?php
require_once "auth.php";
wajib_login("admin");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0);
    $nama = trim($_POST["nama_cabang"] ?? ""); $alamat = trim($_POST["alamat"] ?? ""); $tel = trim($_POST["telepon"] ?? ""); $email = trim($_POST["email"] ?? "");
    if ($nama == "" || $alamat == "" || !preg_match('/^[0-9+]{6,15}$/', $tel) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION["pesan"] = "Data tidak valid. Semua wajib diisi, telepon 6-15 digit, email harus benar.";
        $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0) {
        q("UPDATE cabang SET nama_cabang=?, alamat=?, telepon=?, email=? WHERE id_cabang=?", "ssssi", [$nama, $alamat, $tel, $email, $id]);
        $_SESSION["pesan"] = "Data cabang berhasil diubah.";
    } else {
        q("INSERT INTO cabang (nama_cabang, alamat, telepon, email) VALUES (?,?,?,?)", "ssss", [$nama, $alamat, $tel, $email]);
        $_SESSION["pesan"] = "Cabang baru berhasil ditambahkan.";
    }
    header("Location: cabang.php"); exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    try { q("DELETE FROM cabang WHERE id_cabang=?", "i", [(int)$_POST["hapus"]]); $_SESSION["pesan"] = "Cabang berhasil dihapus."; }
    catch (Exception $e) { $_SESSION["pesan"] = "Cabang tidak bisa dihapus karena masih dipakai kelas, user, atau siswa."; $_SESSION["pesan_galat"] = 1; }
    header("Location: cabang.php"); exit;
}
$edit = isset($_GET["edit"]) ? satu("SELECT * FROM cabang WHERE id_cabang=?", "i", [(int)$_GET["edit"]]) : null;
$data = semua("SELECT c.*, (SELECT COUNT(*) FROM kelas k WHERE k.id_cabang=c.id_cabang) jml_kelas, (SELECT COUNT(*) FROM siswa s WHERE s.id_cabang=c.id_cabang AND s.status='Diterima') jml_siswa FROM cabang c ORDER BY c.id_cabang");
$halaman = "cabang"; $judul_hero = "Cabang"; $teks_hero = "Kelola cabang beserta alamat dan kontaknya.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Cabang" : "Tambah Cabang"; ?></h3>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_cabang"] : 0; ?>">
<div class="row">
<div class="col-sm-6 form-group"><label for="nama_cabang">Nama cabang</label><input class="form-control" id="nama_cabang" name="nama_cabang" value="<?php echo e($edit["nama_cabang"] ?? ""); ?>" required></div>
<div class="col-sm-6 form-group"><label for="alamat">Alamat</label><input class="form-control" id="alamat" name="alamat" value="<?php echo e($edit["alamat"] ?? ""); ?>" required></div>
</div>
<div class="row">
<div class="col-sm-6 form-group"><label for="telepon">Telepon</label><input class="form-control" id="telepon" name="telepon" inputmode="tel" value="<?php echo e($edit["telepon"] ?? ""); ?>" required></div>
<div class="col-sm-6 form-group"><label for="email">Email</label><input type="email" class="form-control" id="email" name="email" value="<?php echo e($edit["email"] ?? ""); ?>" required></div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="cabang.php">Batal</a><?php } ?>
</form>
</div>
<p class="jumlah-hasil"><?php echo count($data); ?> cabang</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:800px">
<thead><tr><th>ID</th><th>Cabang</th><th>Kontak</th><th>Kelas</th><th>Siswa</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $c) { ?>
<tr>
<td><?php echo $c["id_cabang"]; ?></td>
<td class="nama"><?php echo e($c["nama_cabang"]); ?><span class="kecil"><?php echo e($c["alamat"]); ?></span></td>
<td><?php echo e($c["telepon"]); ?><span class="kecil"><?php echo e($c["email"]); ?></span></td>
<td><?php echo $c["jml_kelas"]; ?></td><td><?php echo $c["jml_siswa"]; ?></td>
<td class="aksi-baris">
<a class="tombol-kecil" href="cabang.php?edit=<?php echo $c["id_cabang"]; ?>#nama_cabang" style="text-decoration:none">Ubah</a>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus cabang ini?')"><button type="submit" name="hapus" value="<?php echo $c["id_cabang"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.nama_cabang.value.trim()=="" || f.alamat.value.trim()==""){ err.textContent="Nama dan alamat wajib diisi."; return false; }
if(!/^[0-9+]{6,15}$/.test(f.telepon.value.trim())){ err.textContent="Telepon harus 6-15 digit angka."; return false; }
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())){ err.textContent="Format email tidak valid."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
