<?php
if( !isset($halaman) ){ $halaman = ""; }
if( !isset($judul_hero) ){ $judul_hero = "BIMBINGKU"; }
if( !isset($teks_hero) ){ $teks_hero = ""; }
$masuk = isset($_SESSION["id_user"]);
$role = $masuk ? $_SESSION["role"] : "";
$staf = in_array($role, ["admin", "admin_cabang"]);
function menu_item($kode, $halaman, $file, $teks) {
    $aktif = ($halaman == $kode) ? ' class="aktif"' : '';
    echo '<li' . $aktif . '><a href="' . $file . '">' . $teks . '</a></li>' . "\n";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#3E5BA3">
<title><?php echo e($judul_hero); ?> - BIMBINGKU</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
</head>
<body>
<a class="sr-only sr-only-focusable" href="#konten">Lewati ke konten utama</a>
<header class="site-header">
<div class="container">
<a class="brand-teks" href="index.php" aria-label="BIMBINGKU, ke halaman utama">BIMBINGKU</a>
<button type="button" class="nav-toggle" id="nav-toggle" aria-controls="menu-utama" aria-expanded="false" aria-label="Buka menu">
<span></span><span></span><span></span>
</button>
<nav aria-label="Menu utama">
<ul class="menu-utama" id="menu-utama">
<?php if($masuk){
menu_item("index", $halaman, "index.php", "Dashboard");
if($role == "admin"){ menu_item("cabang", $halaman, "cabang.php", "Cabang"); menu_item("pengajar", $halaman, "pengajar.php", "Pengajar"); }
if($staf){ menu_item("kelas", $halaman, "kelas.php", "Kelas"); menu_item("siswa", $halaman, "siswa.php", "Siswa"); menu_item("pembayaran", $halaman, "pembayaran.php", "Pembayaran"); }
if($role == "pengajar"){ menu_item("kelas", $halaman, "kelas.php", "Kelas"); menu_item("presensi", $halaman, "presensi.php", "Presensi"); menu_item("nilai", $halaman, "nilai.php", "Nilai"); }
if($role == "siswa"){ menu_item("presensi", $halaman, "presensi.php", "Kehadiran"); menu_item("nilai", $halaman, "nilai.php", "Nilai"); menu_item("kartu", $halaman, "kartu.php", "Kartu Member"); }
menu_item("materi", $halaman, "materi.php", "Materi");
menu_item("pengumuman", $halaman, "pengumuman.php", "Pengumuman");
?>
<li class="tombol-masuk"><a href="logout.php">Keluar (<?php echo e(explode(" ", $_SESSION["nama"])[0]); ?>)</a></li>
<?php } else {
menu_item("daftar", $halaman, "daftar.php", "Daftar Siswa");
?>
<li class="tombol-masuk"><a href="login.php">Masuk</a></li>
<?php } ?>
</ul>
</nav>
</div>
</header>
<main class="konten" id="konten">
<section class="hero-polos hero-kecil">
<div class="container">
<h1 class="hero-judul"><?php echo e($judul_hero); ?></h1>
<?php if($teks_hero != ""){ ?>
<p class="hero-teks"><?php echo e($teks_hero); ?></p>
<?php } ?>
</div>
</section>
<?php if(isset($_SESSION["pesan"])){ ?>
<div class="container"><div class="kotak-info<?php echo (isset($_SESSION["pesan_galat"]) ? ' galat' : ''); ?>" role="status"><?php echo e($_SESSION["pesan"]); ?></div></div>
<?php unset($_SESSION["pesan"], $_SESSION["pesan_galat"]); } ?>
