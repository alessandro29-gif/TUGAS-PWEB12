<?php
require_once "auth.php";
wajib_login(["pengajar", "siswa"]);
$role = $_SESSION["role"];

if ($role == "pengajar") {
    $ip = id_pengajar_saya();
    $daftar = semua("SELECT * FROM kelas WHERE id_pengajar=? ORDER BY nama_kelas", "i", [$ip]);
    $idk = (int)($_GET["kelas"] ?? ($_POST["id_kelas"] ?? ($daftar[0]["id_kelas"] ?? 0)));
    $kelas = satu("SELECT * FROM kelas WHERE id_kelas=? AND id_pengajar=?", "ii", [$idk, $ip]);
    $tanggal = $_GET["tanggal"] ?? ($_POST["tanggal"] ?? date("Y-m-d"));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) { $tanggal = date("Y-m-d"); }

    if ($kelas && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
        foreach (($_POST["status"] ?? []) as $ids => $st) {
            if (!in_array($st, ["Hadir", "Izin", "Alfa"])) { continue; }
            if (!satu("SELECT id_siswa FROM siswa WHERE id_siswa=? AND id_kelas=? AND status='Diterima'", "ii", [(int)$ids, $idk])) { continue; }
            q("INSERT INTO presensi (id_kelas, id_siswa, tanggal, status) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status)", "iiss", [$idk, (int)$ids, $tanggal, $st]);
        }
        $_SESSION["pesan"] = "Presensi tanggal " . tgl($tanggal) . " berhasil disimpan.";
        header("Location: presensi.php?kelas=$idk&tanggal=$tanggal"); exit;
    }
    $siswa = $kelas ? semua("SELECT s.id_siswa, s.nama, s.foto, p.status FROM siswa s LEFT JOIN presensi p ON p.id_siswa=s.id_siswa AND p.id_kelas=s.id_kelas AND p.tanggal=? WHERE s.id_kelas=? AND s.status='Diterima' ORDER BY s.nama", "si", [$tanggal, $idk]) : [];
    $rekap = $kelas ? semua("SELECT s.nama, COALESCE(SUM(p.status='Hadir'),0) h, COALESCE(SUM(p.status='Izin'),0) i, COALESCE(SUM(p.status='Alfa'),0) a FROM siswa s LEFT JOIN presensi p ON p.id_siswa=s.id_siswa AND p.id_kelas=s.id_kelas WHERE s.id_kelas=? AND s.status='Diterima' GROUP BY s.id_siswa ORDER BY s.nama", "i", [$idk]) : [];
} else {
    $is = id_siswa_saya();
    $data = semua("SELECT p.*, k.nama_kelas FROM presensi p JOIN kelas k ON k.id_kelas=p.id_kelas WHERE p.id_siswa=? ORDER BY p.tanggal DESC", "i", [$is]);
    $hadir = 0; foreach ($data as $d) { if ($d["status"] == "Hadir") { $hadir++; } }
}

$halaman = "presensi";
$judul_hero = $role == "pengajar" ? "Presensi" : "Kehadiran Saya";
$teks_hero = $role == "pengajar" ? "Catat kehadiran siswa per pertemuan." : "Riwayat kehadiranmu di kelas.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<?php if ($role == "pengajar") { ?>
<form method="get" class="alat-bar">
<select class="form-control saring" name="kelas" aria-label="Pilih kelas">
<?php foreach($daftar as $k){ ?><option value="<?php echo $k["id_kelas"]; ?>"<?php echo $idk == $k["id_kelas"] ? " selected" : ""; ?>><?php echo e($k["nama_kelas"]); ?></option><?php } ?>
</select>
<input type="date" class="form-control" name="tanggal" value="<?php echo e($tanggal); ?>" aria-label="Tanggal pertemuan">
<button type="submit" class="btn-sekunder">Tampilkan</button>
</form>
<?php if (!$kelas) { ?><p>Kamu belum mengampu kelas.</p><?php } else { ?>
<form method="post">
<input type="hidden" name="id_kelas" value="<?php echo $idk; ?>"><input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:560px">
<thead><tr><th>Siswa</th><th>Status kehadiran</th></tr></thead>
<tbody>
<?php foreach ($siswa as $s) { $f = url_foto($s["foto"]); ?>
<tr>
<td class="nama"><?php if($f){ ?><img class="foto-kecil" src="<?php echo $f; ?>" alt="" style="margin-right:10px"><?php } ?><?php echo e($s["nama"]); ?></td>
<td><div class="pilihan-jenis">
<?php foreach(["Hadir","Izin","Alfa"] as $st){ ?>
<label><input type="radio" name="status[<?php echo $s["id_siswa"]; ?>]" value="<?php echo $st; ?>"<?php echo (($s["status"] ?? "Hadir") == $st) ? " checked" : ""; ?>><span><?php echo $st; ?></span></label>
<?php } ?>
</div></td>
</tr>
<?php } ?>
<?php if (!$siswa) { ?><tr><td colspan="2" class="kosong">Belum ada siswa diterima di kelas ini.</td></tr><?php } ?>
</tbody>
</table>
</div>
<?php if ($siswa) { ?><p style="margin-top:20px"><button type="submit" name="simpan" value="1" class="btn-utama">Simpan Presensi</button></p><?php } ?>
</form>
<h2 style="margin-top:40px">Rekap Kehadiran</h2>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:480px">
<thead><tr><th>Siswa</th><th>Hadir</th><th>Izin</th><th>Alfa</th></tr></thead>
<tbody>
<?php foreach ($rekap as $r) { ?><tr><td class="nama"><?php echo e($r["nama"]); ?></td><td><?php echo $r["h"]; ?></td><td><?php echo $r["i"]; ?></td><td><?php echo $r["a"]; ?></td></tr><?php } ?>
</tbody>
</table>
</div>
<?php } ?>
<?php } else { ?>
<p class="jumlah-hasil"><?php echo $hadir; ?> hadir dari <?php echo count($data); ?> pertemuan</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:480px">
<thead><tr><th>Tanggal</th><th>Kelas</th><th>Status</th></tr></thead>
<tbody>
<?php foreach ($data as $d) { ?><tr><td><?php echo tgl($d["tanggal"]); ?></td><td class="nama"><?php echo e($d["nama_kelas"]); ?></td><td><span class="lencana <?php echo kelas_status($d["status"]); ?>"><?php echo e($d["status"]); ?></span></td></tr><?php } ?>
<?php if (!$data) { ?><tr><td colspan="3" class="kosong">Belum ada data kehadiran.</td></tr><?php } ?>
</tbody>
</table>
</div>
<?php } ?>
</div>
</section>
<?php include "footer.php"; ?>
