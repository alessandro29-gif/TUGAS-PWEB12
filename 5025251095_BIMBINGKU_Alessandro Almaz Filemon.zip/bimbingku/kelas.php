<?php
require_once "auth.php";
wajib_login(["admin", "admin_cabang", "pengajar"]);
$role = $_SESSION["role"]; $staf = $role != "pengajar"; $batas = id_cabang_batas();

if ($staf && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0);
    $nama = trim($_POST["nama_kelas"] ?? ""); $cab = $batas ?: (int)($_POST["id_cabang"] ?? 0);
    $ip = (int)($_POST["id_pengajar"] ?? 0); $hari = $_POST["hari"] ?? ""; $jam = $_POST["jam"] ?? "";
    $biaya = (int)($_POST["biaya"] ?? 0); $st = ($_POST["status"] ?? "") == "nonaktif" ? "nonaktif" : "aktif";
    $hariok = in_array($hari, ["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"]);
    $pj = satu("SELECT u.id_cabang FROM pengajar p JOIN user u ON u.id_user=p.id_user WHERE p.id_pengajar=?", "i", [$ip]);
    if ($nama == "" || !$cab || !$hariok || !preg_match('/^\d{2}:\d{2}$/', $jam) || $biaya < 0) {
        $_SESSION["pesan"] = "Data kelas tidak lengkap atau tidak valid."; $_SESSION["pesan_galat"] = 1;
    } elseif (!$pj) {
        $_SESSION["pesan"] = "Pengajar belum dipilih."; $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0) {
        if ($batas && !satu("SELECT id_kelas FROM kelas WHERE id_kelas=? AND id_cabang=?", "ii", [$id, $batas])) { header("Location: kelas.php"); exit; }
        q("UPDATE kelas SET nama_kelas=?, id_cabang=?, id_pengajar=?, hari=?, jam=?, biaya=?, status=? WHERE id_kelas=?", "siissisi", [$nama, $cab, $ip, $hari, $jam, $biaya, $st, $id]);
        $_SESSION["pesan"] = "Kelas berhasil diubah.";
    } else {
        q("INSERT INTO kelas (nama_kelas, id_cabang, id_pengajar, hari, jam, biaya, status) VALUES (?,?,?,?,?,?,?)", "siissis", [$nama, $cab, $ip, $hari, $jam, $biaya, $st]);
        $_SESSION["pesan"] = "Kelas baru berhasil ditambahkan.";
    }
    header("Location: kelas.php"); exit;
}
if ($staf && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    $idk = (int)$_POST["hapus"];
    if (!$batas || satu("SELECT id_kelas FROM kelas WHERE id_kelas=? AND id_cabang=?", "ii", [$idk, $batas])) {
        try { q("DELETE FROM kelas WHERE id_kelas=?", "i", [$idk]); $_SESSION["pesan"] = "Kelas berhasil dihapus."; }
        catch (Exception $e) { $_SESSION["pesan"] = "Kelas tidak bisa dihapus karena sudah punya siswa terdaftar."; $_SESSION["pesan_galat"] = 1; }
    }
    header("Location: kelas.php"); exit;
}

$edit = null;
if ($staf && isset($_GET["edit"])) {
    $edit = satu("SELECT * FROM kelas WHERE id_kelas=?", "i", [(int)$_GET["edit"]]);
    if ($edit && $batas && $edit["id_cabang"] != $batas) { $edit = null; }
}
$cari = trim($_GET["cari"] ?? "");
$sql = "SELECT k.*, c.nama_cabang, u.nama AS nama_pengajar, (SELECT COUNT(*) FROM siswa s WHERE s.id_kelas=k.id_kelas AND s.status='Diterima') jml_siswa FROM kelas k JOIN cabang c ON c.id_cabang=k.id_cabang JOIN pengajar p ON p.id_pengajar=k.id_pengajar JOIN user u ON u.id_user=p.id_user WHERE k.nama_kelas LIKE ?";
$tipe = "s"; $par = ["%$cari%"];
if ($batas) { $sql .= " AND k.id_cabang=?"; $tipe .= "i"; $par[] = $batas; }
if ($role == "pengajar") { $sql .= " AND k.id_pengajar=?"; $tipe .= "i"; $par[] = id_pengajar_saya(); }
$data = semua($sql . " ORDER BY k.id_kelas DESC", $tipe, $par);
$cabang = semua("SELECT * FROM cabang ORDER BY nama_cabang");
$pengajar = semua("SELECT p.id_pengajar, u.nama, u.id_cabang FROM pengajar p JOIN user u ON u.id_user=p.id_user" . ($batas ? " WHERE u.id_cabang=" . $batas : "") . " ORDER BY u.nama");

$halaman = "kelas"; $judul_hero = "Kelas";
$teks_hero = $staf ? "Tambah, ubah, hapus kelas dan atur jadwalnya." : "Daftar kelas yang kamu ampu.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<?php if ($staf) { ?>
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Kelas" : "Tambah Kelas"; ?></h3>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_kelas"] : 0; ?>">
<div class="row">
<div class="col-sm-4 form-group"><label for="nama_kelas">Nama kelas</label><input class="form-control" id="nama_kelas" name="nama_kelas" value="<?php echo e($edit["nama_kelas"] ?? ""); ?>" required></div>
<?php if (!$batas) { ?>
<div class="col-sm-4 form-group"><label for="id_cabang">Cabang</label><select class="form-control" id="id_cabang" name="id_cabang" required><option value="">-- Pilih cabang --</option>
<?php foreach($cabang as $c){ ?><option value="<?php echo $c["id_cabang"]; ?>"<?php echo (($edit["id_cabang"] ?? 0) == $c["id_cabang"]) ? " selected" : ""; ?>><?php echo e($c["nama_cabang"]); ?></option><?php } ?></select></div>
<?php } ?>
<div class="col-sm-4 form-group"><label for="id_pengajar">Pengajar</label><select class="form-control" id="id_pengajar" name="id_pengajar" required><option value="">-- Pilih pengajar --</option>
<?php foreach($pengajar as $p){ ?><option value="<?php echo $p["id_pengajar"]; ?>"<?php echo (($edit["id_pengajar"] ?? 0) == $p["id_pengajar"]) ? " selected" : ""; ?>><?php echo e($p["nama"]); ?></option><?php } ?></select></div>
</div>
<div class="row">
<div class="col-sm-3 form-group"><label for="hari">Hari</label><select class="form-control" id="hari" name="hari" required>
<?php foreach(["Senin","Selasa","Rabu","Kamis","Jumat","Sabtu","Minggu"] as $h){ ?><option<?php echo (($edit["hari"] ?? "Senin") == $h) ? " selected" : ""; ?>><?php echo $h; ?></option><?php } ?></select></div>
<div class="col-sm-3 form-group"><label for="jam">Jam</label><input type="time" class="form-control" id="jam" name="jam" value="<?php echo e(substr($edit["jam"] ?? "15:00", 0, 5)); ?>" required></div>
<div class="col-sm-3 form-group"><label for="biaya">Biaya (Rp)</label><input type="number" min="0" step="1000" class="form-control" id="biaya" name="biaya" value="<?php echo e($edit["biaya"] ?? 0); ?>" required></div>
<div class="col-sm-3 form-group"><label for="status">Status</label><select class="form-control" id="status" name="status"><option value="aktif"<?php echo (($edit["status"] ?? "aktif") == "aktif") ? " selected" : ""; ?>>aktif</option><option value="nonaktif"<?php echo (($edit["status"] ?? "") == "nonaktif") ? " selected" : ""; ?>>nonaktif</option></select></div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="kelas.php">Batal</a><?php } ?>
</form>
</div>
<?php } ?>
<form method="get" class="alat-bar">
<input type="search" class="form-control cari" name="cari" placeholder="Cari nama kelas" value="<?php echo e($cari); ?>" aria-label="Cari kelas">
<button type="submit" class="btn-sekunder">Cari</button>
</form>
<p class="jumlah-hasil"><?php echo count($data); ?> kelas</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:900px">
<thead><tr><th>ID</th><th>Kelas</th><th>Cabang</th><th>Pengajar</th><th>Jadwal</th><th>Biaya</th><th>Siswa</th><th>Status</th><?php if($staf){ ?><th>Aksi</th><?php } ?></tr></thead>
<tbody>
<?php foreach ($data as $k) { ?>
<tr>
<td><?php echo $k["id_kelas"]; ?></td>
<td class="nama"><?php echo e($k["nama_kelas"]); ?></td>
<td><?php echo e($k["nama_cabang"]); ?></td><td><?php echo e($k["nama_pengajar"]); ?></td>
<td><?php echo e($k["hari"]); ?>, <?php echo substr($k["jam"], 0, 5); ?></td>
<td class="angka-kanan"><?php echo rupiah($k["biaya"]); ?></td>
<td><?php echo $k["jml_siswa"]; ?></td>
<td><span class="lencana <?php echo kelas_status($k["status"]); ?>"><?php echo e($k["status"]); ?></span></td>
<?php if($staf){ ?><td class="aksi-baris">
<a class="tombol-kecil" href="kelas.php?edit=<?php echo $k["id_kelas"]; ?>#nama_kelas" style="text-decoration:none">Ubah</a>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus kelas ini?')"><button type="submit" name="hapus" value="<?php echo $k["id_kelas"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td><?php } ?>
</tr>
<?php } ?>
<?php if (!$data) { ?><tr><td colspan="9" class="kosong">Belum ada kelas.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<?php if ($staf) { ?>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.nama_kelas.value.trim()==""){ err.textContent="Nama kelas wajib diisi."; return false; }
if(f.id_cabang && f.id_cabang.value==""){ err.textContent="Pilih cabang."; return false; }
if(f.id_pengajar.value==""){ err.textContent="Pilih pengajar."; return false; }
if(f.jam.value==""){ err.textContent="Jam wajib diisi."; return false; }
if(f.biaya.value=="" || Number(f.biaya.value) < 0){ err.textContent="Biaya tidak valid."; return false; }
return true;
}
</script>
<?php } ?>
<?php include "footer.php"; ?>
