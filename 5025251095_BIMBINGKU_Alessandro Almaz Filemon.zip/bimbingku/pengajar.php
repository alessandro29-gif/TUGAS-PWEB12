<?php
require_once "auth.php";
wajib_login("admin");
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0);
    $nama = trim($_POST["nama"] ?? ""); $email = trim($_POST["email"] ?? ""); $pw = $_POST["password"] ?? "";
    $ahli = trim($_POST["keahlian"] ?? ""); $thn = (int)($_POST["pengalaman_tahun"] ?? 0); $cab = (int)($_POST["id_cabang"] ?? 0);
    $lama = $id ? satu("SELECT p.*, u.email FROM pengajar p JOIN user u ON u.id_user=p.id_user WHERE p.id_pengajar=?", "i", [$id]) : null;
    $dobel = satu("SELECT id_user FROM user WHERE email=?" . ($lama ? " AND id_user<>" . (int)$lama["id_user"] : ""), "s", [$email]);
    if ($nama == "" || $ahli == "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || $thn < 0 || $thn > 60 || !$cab) {
        $_SESSION["pesan"] = "Data tidak valid. Periksa nama, email, keahlian, pengalaman, dan cabang.";
        $_SESSION["pesan_galat"] = 1;
    } elseif ($dobel) {
        $_SESSION["pesan"] = "Email sudah dipakai akun lain."; $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0 && $lama) {
        q("UPDATE user SET nama=?, email=?, id_cabang=? WHERE id_user=?", "ssii", [$nama, $email, $cab, $lama["id_user"]]);
        if (strlen($pw) >= 6) { q("UPDATE user SET password=? WHERE id_user=?", "si", [password_hash($pw, PASSWORD_DEFAULT), $lama["id_user"]]); }
        q("UPDATE pengajar SET keahlian=?, pengalaman_tahun=? WHERE id_pengajar=?", "sii", [$ahli, $thn, $id]);
        $_SESSION["pesan"] = "Data pengajar berhasil diubah.";
    } elseif (strlen($pw) < 6) {
        $_SESSION["pesan"] = "Password pengajar baru minimal 6 karakter."; $_SESSION["pesan_galat"] = 1;
    } else {
        q("INSERT INTO user (nama, email, password, role, id_cabang) VALUES (?,?,?, 'pengajar', ?)", "sssi", [$nama, $email, password_hash($pw, PASSWORD_DEFAULT), $cab]);
        q("INSERT INTO pengajar (id_user, keahlian, pengalaman_tahun) VALUES (?,?,?)", "isi", [id_baru(), $ahli, $thn]);
        $_SESSION["pesan"] = "Pengajar baru berhasil ditambahkan.";
    }
    header("Location: pengajar.php"); exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    $p = satu("SELECT id_user FROM pengajar WHERE id_pengajar=?", "i", [(int)$_POST["hapus"]]);
    try { if ($p) { q("DELETE FROM user WHERE id_user=?", "i", [$p["id_user"]]); } $_SESSION["pesan"] = "Pengajar berhasil dihapus."; }
    catch (Exception $e) { $_SESSION["pesan"] = "Pengajar tidak bisa dihapus karena masih mengampu kelas."; $_SESSION["pesan_galat"] = 1; }
    header("Location: pengajar.php"); exit;
}
$edit = isset($_GET["edit"]) ? satu("SELECT p.*, u.nama, u.email, u.id_cabang FROM pengajar p JOIN user u ON u.id_user=p.id_user WHERE p.id_pengajar=?", "i", [(int)$_GET["edit"]]) : null;
$cabang = semua("SELECT * FROM cabang ORDER BY nama_cabang");
$data = semua("SELECT p.*, u.nama, u.email, c.nama_cabang, (SELECT COUNT(*) FROM kelas k WHERE k.id_pengajar=p.id_pengajar) jml_kelas FROM pengajar p JOIN user u ON u.id_user=p.id_user LEFT JOIN cabang c ON c.id_cabang=u.id_cabang ORDER BY p.id_pengajar");
$halaman = "pengajar"; $judul_hero = "Pengajar"; $teks_hero = "Kelola data pengajar, keahlian, dan akun loginnya.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Pengajar" : "Tambah Pengajar"; ?></h3>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_pengajar"] : 0; ?>">
<div class="row">
<div class="col-sm-4 form-group"><label for="nama">Nama</label><input class="form-control" id="nama" name="nama" value="<?php echo e($edit["nama"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="email">Email (login)</label><input type="email" class="form-control" id="email" name="email" value="<?php echo e($edit["email"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="password">Password <?php echo $edit ? "(kosongkan jika tidak diganti)" : ""; ?></label><input type="password" class="form-control" id="password" name="password"></div>
</div>
<div class="row">
<div class="col-sm-4 form-group"><label for="keahlian">Keahlian</label><input class="form-control" id="keahlian" name="keahlian" value="<?php echo e($edit["keahlian"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="pengalaman_tahun">Pengalaman (tahun)</label><input type="number" min="0" max="60" class="form-control" id="pengalaman_tahun" name="pengalaman_tahun" value="<?php echo e($edit["pengalaman_tahun"] ?? 0); ?>" required></div>
<div class="col-sm-4 form-group"><label for="id_cabang">Cabang</label>
<select class="form-control" id="id_cabang" name="id_cabang" required><option value="">-- Pilih cabang --</option>
<?php foreach($cabang as $c){ ?><option value="<?php echo $c["id_cabang"]; ?>"<?php echo (($edit["id_cabang"] ?? 0) == $c["id_cabang"]) ? " selected" : ""; ?>><?php echo e($c["nama_cabang"]); ?></option><?php } ?>
</select></div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="pengajar.php">Batal</a><?php } ?>
</form>
</div>
<p class="jumlah-hasil"><?php echo count($data); ?> pengajar</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:800px">
<thead><tr><th>ID</th><th>Pengajar</th><th>Keahlian</th><th>Pengalaman</th><th>Cabang</th><th>Kelas</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $p) { ?>
<tr>
<td><?php echo $p["id_pengajar"]; ?></td>
<td class="nama"><?php echo e($p["nama"]); ?><span class="kecil"><?php echo e($p["email"]); ?></span></td>
<td><?php echo e($p["keahlian"]); ?></td><td><?php echo (int)$p["pengalaman_tahun"]; ?> th</td>
<td><?php echo e($p["nama_cabang"]); ?></td><td><?php echo $p["jml_kelas"]; ?></td>
<td class="aksi-baris">
<a class="tombol-kecil" href="pengajar.php?edit=<?php echo $p["id_pengajar"]; ?>#nama" style="text-decoration:none">Ubah</a>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus pengajar ini?')"><button type="submit" name="hapus" value="<?php echo $p["id_pengajar"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td>
</tr>
<?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.nama.value.trim()=="" || f.keahlian.value.trim()==""){ err.textContent="Nama dan keahlian wajib diisi."; return false; }
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())){ err.textContent="Format email tidak valid."; return false; }
if(f.id.value=="0" && f.password.value.length < 6){ err.textContent="Password minimal 6 karakter."; return false; }
if(f.id_cabang.value==""){ err.textContent="Pilih cabang."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
