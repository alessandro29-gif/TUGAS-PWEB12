<?php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "bimbingku";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $koneksi = mysqli_connect($host, $user, $pass, $db);
    mysqli_set_charset($koneksi, "utf8mb4");
} catch (Exception $e) {
    die("Koneksi database gagal. Pastikan MySQL menyala dan database 'bimbingku' sudah di-import.");
}
