<?php
require_once "auth.php";
wajib_login();
$role = $_SESSION["role"]; $staf = in_array($role, ["admin", "admin_cabang"]);

if ($staf && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0); $judul = trim($_POST["judul"] ?? ""); $isi = trim($_POST["isi"] ?? ""); $target = $_POST["target"] ?? "";
    if ($judul == "" || $isi == "" || !in_array($target, ["Semua", "Pengajar", "Siswa"])) {
        $_SESSION["pesan"] = "Judul, isi, dan target wajib diisi."; $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0) {
        q("UPDATE pengumuman SET judul=?, isi=?, target=? WHERE id_pengumuman=?", "sssi", [$judul, $isi, $target, $id]);
        $_SESSION["pesan"] = "Pengumuman berhasil diubah.";
    } else {
        q("INSERT INTO pengumuman (judul, isi, target, dibuat_oleh) VALUES (?,?,?,?)", "sssi", [$judul, $isi, $target, $_SESSION["id_user"]]);
        $_SESSION["pesan"] = "Pengumuman berhasil dibuat.";
    }
    header("Location: pengumuman.php"); exit;
}
if ($staf && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    q("DELETE FROM pengumuman WHERE id_pengumuman=?", "i", [(int)$_POST["hapus"]]);
    $_SESSION["pesan"] = "Pengumuman dihapus.";
    header("Location: pengumuman.php"); exit;
}
$edit = ($staf && isset($_GET["edit"])) ? satu("SELECT * FROM pengumuman WHERE id_pengumuman=?", "i", [(int)$_GET["edit"]]) : null;
if ($staf) { $data = semua("SELECT p.*, u.nama FROM pengumuman p JOIN user u ON u.id_user=p.dibuat_oleh ORDER BY p.id_pengumuman DESC"); }
else { $data = semua("SELECT p.*, u.nama FROM pengumuman p JOIN user u ON u.id_user=p.dibuat_oleh WHERE p.target IN ('Semua', ?) ORDER BY p.id_pengumuman DESC", "s", [$role == "pengajar" ? "Pengajar" : "Siswa"]); }

$halaman = "pengumuman"; $judul_hero = "Pengumuman"; $teks_hero = "Informasi ujian, libur, dan acara.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<?php if ($staf) { ?>
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Pengumuman" : "Buat Pengumuman"; ?></h3>
<form method="post" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_pengumuman"] : 0; ?>">
<div class="row">
<div class="col-sm-8 form-group"><label for="judul">Judul</label><input class="form-control" id="judul" name="judul" value="<?php echo e($edit["judul"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="target">Ditujukan ke</label><select class="form-control" id="target" name="target">
<?php foreach(["Semua","Pengajar","Siswa"] as $t){ ?><option<?php echo (($edit["target"] ?? "Semua") == $t) ? " selected" : ""; ?>><?php echo $t; ?></option><?php } ?></select></div>
</div>
<div class="form-group"><label for="isi">Isi</label><textarea class="form-control" id="isi" name="isi" rows="3" required><?php echo e($edit["isi"] ?? ""); ?></textarea></div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="pengumuman.php">Batal</a><?php } ?>
</form>
</div>
<?php } ?>
<?php foreach ($data as $p) { ?>
<div class="kotak-info">
<strong><?php echo e($p["judul"]); ?></strong> <span class="lencana lencana-menunggu"><?php echo e($p["target"]); ?></span><br>
<?php echo nl2br(e($p["isi"])); ?><br>
<span class="kecil"><?php echo e($p["nama"]); ?> &middot; <?php echo tgl($p["created_at"]); ?></span>
<?php if ($staf) { ?>
<div style="margin-top:8px">
<a class="tombol-kecil" href="pengumuman.php?edit=<?php echo $p["id_pengumuman"]; ?>#judul" style="text-decoration:none">Ubah</a>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus pengumuman ini?')"><button type="submit" name="hapus" value="<?php echo $p["id_pengumuman"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</div>
<?php } ?>
</div>
<?php } ?>
<?php if (!$data) { ?><p>Belum ada pengumuman.</p><?php } ?>
</div>
</section>
<?php if ($staf) { ?>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.judul.value.trim()=="" || f.isi.value.trim()==""){ err.textContent="Judul dan isi wajib diisi."; return false; }
return true;
}
</script>
<?php } ?>
<?php include "footer.php"; ?>
