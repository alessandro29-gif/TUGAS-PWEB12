</main>
<footer class="site-footer">
<div class="container">
<div class="row">
<div class="col-sm-4">
<p class="brand-teks">BIMBINGKU</p>
<p style="margin-top:8px">Sistem manajemen kursus dan bimbingan belajar berbasis web.</p>
</div>
<div class="col-sm-4">
<h4>Halaman</h4>
<ul>
<li><a href="index.php">Dashboard</a></li>
<li><a href="daftar.php">Pendaftaran Siswa</a></li>
<li><a href="pengumuman.php">Pengumuman</a></li>
</ul>
</div>
<div class="col-sm-4">
<h4>Kontak</h4>
<p style="margin-bottom:8px">BIMBINGKU<br>Surabaya, Jawa Timur</p>
</div>
</div>
<p class="hak-cipta">&copy; 2026 BIMBINGKU. Tugas PHP dan MySQL.</p>
</div>
</footer>
<script>
var tombol = document.getElementById("nav-toggle");
var menu = document.getElementById("menu-utama");
if(tombol){
tombol.addEventListener("click", function(){
var buka = menu.classList.toggle("terbuka");
tombol.setAttribute("aria-expanded", buka ? "true" : "false");
});
}
</script>
</body>
</html>
