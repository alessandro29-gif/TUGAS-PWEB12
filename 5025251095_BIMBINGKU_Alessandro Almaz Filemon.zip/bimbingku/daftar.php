<?php
require_once "auth.php";
$galat = [];
$v = ["nama" => "", "tgl_lahir" => "", "email" => "", "no_hp" => "", "alamat" => "", "id_cabang" => 0, "id_kelas" => 0];
$cabang = semua("SELECT * FROM cabang ORDER BY nama_cabang");
$kelas = semua("SELECT * FROM kelas WHERE status='aktif' ORDER BY nama_kelas");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($v as $k => $_) { $v[$k] = trim($_POST[$k] ?? ""); }
    $v["id_cabang"] = (int)$v["id_cabang"]; $v["id_kelas"] = (int)$v["id_kelas"];
    if ($v["nama"] == "") { $galat[] = "Nama lengkap wajib diisi."; }
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $v["tgl_lahir"]) || $v["tgl_lahir"] > date("Y-m-d")) { $galat[] = "Tanggal lahir tidak valid."; }
    if (!filter_var($v["email"], FILTER_VALIDATE_EMAIL)) { $galat[] = "Format email tidak valid."; }
    if (!preg_match('/^[0-9+]{8,15}$/', $v["no_hp"])) { $galat[] = "No HP harus 8-15 digit angka."; }
    if ($v["alamat"] == "") { $galat[] = "Alamat wajib diisi."; }
    $k = satu("SELECT * FROM kelas WHERE id_kelas=? AND id_cabang=? AND status='aktif'", "ii", [$v["id_kelas"], $v["id_cabang"]]);
    if (!$k) { $galat[] = "Pilih cabang dan kelas yang sesuai."; }
    if (!$galat && satu("SELECT id_siswa FROM siswa WHERE email=? AND id_kelas=?", "si", [$v["email"], $v["id_kelas"]])) {
        $galat[] = "Email ini sudah terdaftar di kelas tersebut.";
    }
    list($foto, $g1) = simpan_gambar("foto", "foto", true);
    if ($g1 != "") { $galat[] = $g1; }
    list($bukti, $g2) = simpan_gambar("bukti", "bukti", false);
    if ($g2 != "") { $galat[] = "Bukti pembayaran: " . $g2; }

    if (!$galat) {
        q("INSERT INTO siswa (nama, tgl_lahir, alamat, no_hp, email, id_cabang, id_kelas, foto, bukti_bayar, status) VALUES (?,?,?,?,?,?,?,?,?, 'Menunggu')",
          "sssssiiss", [$v["nama"], $v["tgl_lahir"], $v["alamat"], $v["no_hp"], $v["email"], $v["id_cabang"], $v["id_kelas"], $foto, $bukti]);
        $id = id_baru();
        q("INSERT INTO pembayaran (id_siswa, id_kelas, jumlah, tanggal, bukti, status) VALUES (?,?,?,CURDATE(),?, 'Menunggu')",
          "iiis", [$id, $v["id_kelas"], $k["biaya"], $bukti]);
        header("Location: daftar.php?ok=" . $id); exit;
    } else {
        hapus_berkas("foto", $foto); hapus_berkas("bukti", $bukti);
    }
}

$sukses = null;
if (isset($_GET["ok"])) { $sukses = satu("SELECT id_siswa, nama FROM siswa WHERE id_siswa=?", "i", [(int)$_GET["ok"]]); }

$halaman = "daftar";
$judul_hero = "Pendaftaran Siswa";
$teks_hero = "Isi data diri, unggah pas foto, lalu tunggu verifikasi dari admin cabang.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<?php if ($sukses) { ?>
<div class="panel-sukses">
<h2>Pendaftaran terkirim!</h2>
<dl class="ringkasan">
<dt>Nama</dt><dd><?php echo e($sukses["nama"]); ?></dd>
<dt>Nomor registrasi</dt><dd>REG-<?php echo str_pad($sukses["id_siswa"], 5, "0", STR_PAD_LEFT); ?></dd>
<dt>Status</dt><dd><span class="lencana lencana-menunggu">Menunggu verifikasi</span></dd>
</dl>
<p>Simpan nomor registrasi ini. Setelah diterima, kamu bisa masuk dengan email pendaftaran dan password berupa tanggal lahir (format ddmmyyyy).</p>
<a class="btn-utama" href="daftar.php">Daftar Lagi</a>
</div>
<?php } else { ?>
<div class="kartu-form">
<?php if($galat){ ?><div class="kotak-info galat" role="alert"><?php foreach($galat as $g){ echo e($g) . "<br>"; } ?></div><?php } ?>
<form method="post" enctype="multipart/form-data" novalidate onsubmit="return cek(this)">
<div class="row">
<div class="col-sm-6 form-group"><label for="nama">Nama lengkap</label><input class="form-control" id="nama" name="nama" value="<?php echo e($v["nama"]); ?>" required></div>
<div class="col-sm-6 form-group"><label for="tgl_lahir">Tanggal lahir</label><input type="date" class="form-control" id="tgl_lahir" name="tgl_lahir" max="<?php echo date("Y-m-d"); ?>" value="<?php echo e($v["tgl_lahir"]); ?>" required></div>
</div>
<div class="row">
<div class="col-sm-6 form-group"><label for="email">Email</label><input type="email" class="form-control" id="email" name="email" value="<?php echo e($v["email"]); ?>" required></div>
<div class="col-sm-6 form-group"><label for="no_hp">No HP</label><input class="form-control" id="no_hp" name="no_hp" inputmode="tel" value="<?php echo e($v["no_hp"]); ?>" required></div>
</div>
<div class="form-group"><label for="alamat">Alamat lengkap</label><textarea class="form-control" id="alamat" name="alamat" rows="2" required><?php echo e($v["alamat"]); ?></textarea></div>
<div class="row">
<div class="col-sm-6 form-group">
<label for="id_cabang">Cabang</label>
<select class="form-control" id="id_cabang" name="id_cabang" required>
<option value="">-- Pilih cabang --</option>
<?php foreach($cabang as $c){ ?><option value="<?php echo $c["id_cabang"]; ?>"<?php echo $v["id_cabang"] == $c["id_cabang"] ? " selected" : ""; ?>><?php echo e($c["nama_cabang"]); ?></option><?php } ?>
</select>
</div>
<div class="col-sm-6 form-group">
<label for="id_kelas">Kelas</label>
<select class="form-control" id="id_kelas" name="id_kelas" required>
<option value="">-- Pilih kelas --</option>
<?php foreach($kelas as $k){ ?><option value="<?php echo $k["id_kelas"]; ?>" data-cabang="<?php echo $k["id_cabang"]; ?>" data-biaya="<?php echo $k["biaya"]; ?>"<?php echo $v["id_kelas"] == $k["id_kelas"] ? " selected" : ""; ?>><?php echo e($k["nama_kelas"]); ?> (<?php echo e($k["hari"]); ?>)</option><?php } ?>
</select>
<p class="petunjuk" id="info-biaya"></p>
</div>
</div>
<div class="row">
<div class="col-sm-4 form-group">
<label for="foto">Pas foto (3x4)</label>
<input type="file" class="form-control" id="foto" name="foto" accept="image/png, image/jpeg" required style="height:auto;padding:10px 12px">
<p class="petunjuk">Format JPG/PNG, maksimal 2 MB. Pakai foto wajah menghadap depan.</p>
</div>
<div class="col-sm-3 form-group">
<span class="judul-isian">Pratinjau</span>
<div class="pratinjau-foto" id="pratinjau"><span>Belum ada foto</span></div>
</div>
<div class="col-sm-5 form-group">
<label for="bukti">Bukti pembayaran (opsional)</label>
<input type="file" class="form-control" id="bukti" name="bukti" accept="image/png, image/jpeg" style="height:auto;padding:10px 12px">
<p class="petunjuk">Boleh diunggah nanti. JPG/PNG, maksimal 2 MB.</p>
</div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" class="btn-utama">Kirim Pendaftaran</button>
<button type="reset" class="btn-sekunder" onclick="setTimeout(resetForm, 0)">Reset</button>
</form>
</div>
<?php } ?>
</div>
</section>
<script>
var MAKS = 2 * 1024 * 1024;
var elFoto = document.getElementById("foto");
var kotak = document.getElementById("pratinjau");
function cekBerkas(file){
if(!file){ return ""; }
if(["image/jpeg","image/png"].indexOf(file.type) < 0){ return "File harus berupa gambar JPG atau PNG."; }
if(file.size > MAKS){ return "Ukuran file maksimal 2 MB."; }
return "";
}
function resetForm(){
kotak.innerHTML = "<span>Belum ada foto</span>";
saring();
}
if(elFoto){
elFoto.addEventListener("change", function(){
var f = this.files[0]; var err = document.getElementById("err");
var g = cekBerkas(f);
if(g != ""){ err.textContent = "Pas foto: " + g; this.value = ""; resetForm(); return; }
err.textContent = "";
if(!f){ resetForm(); return; }
var r = new FileReader();
r.onload = function(ev){ kotak.innerHTML = ""; var im = document.createElement("img"); im.src = ev.target.result; im.alt = "Pratinjau pas foto"; kotak.appendChild(im); };
r.readAsDataURL(f);
});
}
var selCabang = document.getElementById("id_cabang");
var selKelas = document.getElementById("id_kelas");
function saring(){
if(!selCabang){ return; }
var c = selCabang.value; var ada = false;
for(var i = 0; i < selKelas.options.length; i++){
var o = selKelas.options[i];
if(o.value == ""){ continue; }
var cocok = (c != "" && o.getAttribute("data-cabang") == c);
o.hidden = !cocok; o.disabled = !cocok;
if(!cocok && o.selected){ selKelas.value = ""; }
}
var s = selKelas.options[selKelas.selectedIndex];
document.getElementById("info-biaya").textContent = (s && s.getAttribute("data-biaya")) ? "Biaya: Rp " + Number(s.getAttribute("data-biaya")).toLocaleString("id-ID") : "";
}
if(selCabang){ selCabang.addEventListener("change", saring); selKelas.addEventListener("change", saring); saring(); }
function cek(f){
var err = document.getElementById("err");
if(f.nama.value.trim()=="" || f.alamat.value.trim()==""){ err.textContent="Nama dan alamat wajib diisi."; return false; }
if(f.tgl_lahir.value==""){ err.textContent="Tanggal lahir wajib diisi."; return false; }
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())){ err.textContent="Format email tidak valid."; return false; }
if(!/^[0-9+]{8,15}$/.test(f.no_hp.value.trim())){ err.textContent="No HP harus 8-15 digit angka."; return false; }
if(f.id_cabang.value=="" || f.id_kelas.value==""){ err.textContent="Pilih cabang dan kelas."; return false; }
if(f.foto.files.length == 0){ err.textContent="Pas foto wajib diunggah."; return false; }
var g = cekBerkas(f.bukti.files[0]);
if(g != ""){ err.textContent = "Bukti pembayaran: " + g; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
