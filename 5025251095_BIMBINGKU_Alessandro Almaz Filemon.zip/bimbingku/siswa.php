<?php
require_once "auth.php";
wajib_login(["admin", "admin_cabang"]);
$batas = id_cabang_batas();

function boleh_siswa($id, $batas) {
    $s = satu("SELECT * FROM siswa WHERE id_siswa=?", "i", [$id]);
    if (!$s || ($batas && $s["id_cabang"] != $batas)) { return null; }
    return $s;
}

// ubah status pendaftaran
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["status"])) {
    $s = boleh_siswa((int)$_POST["id"], $batas);
    $st = $_POST["status"];
    if ($s && in_array($st, ["Diterima", "Ditolak", "Menunggu"])) {
        if ($st == "Diterima" && !$s["id_user"]) {
            if (satu("SELECT id_user FROM user WHERE email=?", "s", [$s["email"]])) {
                $_SESSION["pesan"] = "Email sudah dipakai akun lain, ubah email siswa dulu.";
                $_SESSION["pesan_galat"] = 1;
                header("Location: siswa.php"); exit;
            }
            $pass = date("dmY", strtotime($s["tgl_lahir"]));
            q("INSERT INTO user (nama, email, password, role, id_cabang) VALUES (?,?,?, 'siswa', ?)", "sssi", [$s["nama"], $s["email"], password_hash($pass, PASSWORD_DEFAULT), $s["id_cabang"]]);
            $uid = id_baru();
            $no = "BMB-" . date("Y") . "-" . str_pad($s["id_siswa"], 4, "0", STR_PAD_LEFT);
            q("UPDATE siswa SET id_user=?, no_kartu=? WHERE id_siswa=?", "isi", [$uid, $no, $s["id_siswa"]]);
            $_SESSION["pesan"] = "Siswa diterima. Akun dibuat: " . $s["email"] . " / password " . $pass . " (tanggal lahir ddmmyyyy).";
        } else {
            $_SESSION["pesan"] = "Status pendaftaran diubah menjadi " . $st . ".";
        }
        q("UPDATE siswa SET status=? WHERE id_siswa=?", "si", [$st, $s["id_siswa"]]);
    }
    header("Location: siswa.php"); exit;
}

// simpan (tambah / ubah)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $id = (int)($_POST["id"] ?? 0);
    $nama = trim($_POST["nama"] ?? ""); $tgl_lahir = trim($_POST["tgl_lahir"] ?? ""); $email = trim($_POST["email"] ?? "");
    $hp = trim($_POST["no_hp"] ?? ""); $alamat = trim($_POST["alamat"] ?? "");
    $id_kelas = (int)($_POST["id_kelas"] ?? 0);
    $k = satu("SELECT * FROM kelas WHERE id_kelas=?", "i", [$id_kelas]);
    $lama = $id ? boleh_siswa($id, $batas) : null;
    $galat = "";
    if ($nama == "" || $alamat == "") { $galat = "Nama dan alamat wajib diisi."; }
    elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tgl_lahir)) { $galat = "Tanggal lahir tidak valid."; }
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $galat = "Format email tidak valid."; }
    elseif (!preg_match('/^[0-9+]{8,15}$/', $hp)) { $galat = "No HP harus 8-15 digit angka."; }
    elseif (!$k || ($batas && $k["id_cabang"] != $batas)) { $galat = "Kelas tidak valid."; }
    elseif ($id && !$lama) { $galat = "Data siswa tidak ditemukan."; }

    if ($galat == "") {
        list($foto, $gf) = simpan_gambar("foto", "foto", $id == 0);
        if ($gf != "") { $galat = $gf; }
    }
    if ($galat != "") {
        $_SESSION["pesan"] = $galat; $_SESSION["pesan_galat"] = 1;
    } elseif ($id > 0) {
        if ($foto) { hapus_berkas("foto", $lama["foto"]); } else { $foto = $lama["foto"]; }
        q("UPDATE siswa SET nama=?, tgl_lahir=?, email=?, no_hp=?, alamat=?, id_cabang=?, id_kelas=?, foto=? WHERE id_siswa=?",
          "sssssiisi", [$nama, $tgl_lahir, $email, $hp, $alamat, $k["id_cabang"], $id_kelas, $foto, $id]);
        $_SESSION["pesan"] = "Data siswa berhasil diubah.";
    } else {
        q("INSERT INTO siswa (nama, tgl_lahir, alamat, no_hp, email, id_cabang, id_kelas, foto, status) VALUES (?,?,?,?,?,?,?,?, 'Menunggu')",
          "sssssiis", [$nama, $tgl_lahir, $alamat, $hp, $email, $k["id_cabang"], $id_kelas, $foto]);
        $_SESSION["pesan"] = "Siswa baru ditambahkan dengan status Menunggu.";
    }
    header("Location: siswa.php"); exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    $s = boleh_siswa((int)$_POST["hapus"], $batas);
    if ($s) {
        q("DELETE FROM siswa WHERE id_siswa=?", "i", [$s["id_siswa"]]);
        if ($s["id_user"]) { q("DELETE FROM user WHERE id_user=?", "i", [$s["id_user"]]); }
        hapus_berkas("foto", $s["foto"]); hapus_berkas("bukti", $s["bukti_bayar"]);
        $_SESSION["pesan"] = "Siswa berhasil dihapus.";
    }
    header("Location: siswa.php"); exit;
}

$edit = isset($_GET["edit"]) ? boleh_siswa((int)$_GET["edit"], $batas) : null;
$cari = trim($_GET["cari"] ?? ""); $saring = $_GET["status"] ?? "";
$sql = "SELECT s.*, k.nama_kelas, c.nama_cabang FROM siswa s JOIN kelas k ON k.id_kelas=s.id_kelas JOIN cabang c ON c.id_cabang=s.id_cabang WHERE (s.nama LIKE ? OR s.email LIKE ?)";
$tipe = "ss"; $par = ["%$cari%", "%$cari%"];
if ($batas) { $sql .= " AND s.id_cabang=?"; $tipe .= "i"; $par[] = $batas; }
if (in_array($saring, ["Menunggu", "Diterima", "Ditolak"])) { $sql .= " AND s.status=?"; $tipe .= "s"; $par[] = $saring; }
$data = semua($sql . " ORDER BY s.id_siswa DESC", $tipe, $par);
$daftar_kelas = $batas ? semua("SELECT k.*, c.nama_cabang FROM kelas k JOIN cabang c ON c.id_cabang=k.id_cabang WHERE k.id_cabang=? ORDER BY k.nama_kelas", "i", [$batas])
                       : semua("SELECT k.*, c.nama_cabang FROM kelas k JOIN cabang c ON c.id_cabang=k.id_cabang ORDER BY c.nama_cabang, k.nama_kelas");

$halaman = "siswa";
$judul_hero = "Data Siswa";
$teks_hero = "Verifikasi pendaftaran, kelola data, dan pas foto siswa.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0"><?php echo $edit ? "Ubah Siswa" : "Tambah Siswa"; ?></h3>
<form method="post" enctype="multipart/form-data" novalidate onsubmit="return cek(this)">
<input type="hidden" name="id" value="<?php echo $edit ? (int)$edit["id_siswa"] : 0; ?>">
<div class="row">
<div class="col-sm-4 form-group"><label for="nama">Nama lengkap</label><input class="form-control" id="nama" name="nama" value="<?php echo e($edit["nama"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="tgl_lahir">Tanggal lahir</label><input type="date" class="form-control" id="tgl_lahir" name="tgl_lahir" value="<?php echo e($edit["tgl_lahir"] ?? ""); ?>" required></div>
<div class="col-sm-4 form-group"><label for="no_hp">No HP</label><input class="form-control" id="no_hp" name="no_hp" inputmode="tel" value="<?php echo e($edit["no_hp"] ?? ""); ?>" required></div>
</div>
<div class="row">
<div class="col-sm-4 form-group"><label for="email">Email</label><input type="email" class="form-control" id="email" name="email" value="<?php echo e($edit["email"] ?? ""); ?>" required></div>
<div class="col-sm-8 form-group"><label for="alamat">Alamat</label><input class="form-control" id="alamat" name="alamat" value="<?php echo e($edit["alamat"] ?? ""); ?>" required></div>
</div>
<div class="row">
<div class="col-sm-4 form-group">
<label for="id_kelas">Kelas</label>
<select class="form-control" id="id_kelas" name="id_kelas" required>
<option value="">-- Pilih kelas --</option>
<?php foreach($daftar_kelas as $k){ ?><option value="<?php echo $k["id_kelas"]; ?>"<?php echo (($edit["id_kelas"] ?? 0) == $k["id_kelas"]) ? " selected" : ""; ?>><?php echo e($k["nama_kelas"] . " - " . $k["nama_cabang"]); ?></option><?php } ?>
</select>
</div>
<div class="col-sm-5 form-group">
<label for="foto">Pas foto <?php echo $edit ? "(kosongkan jika tidak diganti)" : "(wajib)"; ?></label>
<input type="file" class="form-control" id="foto" name="foto" accept="image/png, image/jpeg" style="height:auto;padding:10px 12px">
<p class="petunjuk">JPG/PNG, maksimal 2 MB.</p>
</div>
<div class="col-sm-3 form-group">
<span class="judul-isian">Pratinjau</span>
<div class="pratinjau-foto" id="pratinjau">
<?php if($edit && url_foto($edit["foto"])){ ?><img src="<?php echo url_foto($edit["foto"]); ?>" alt="Pas foto saat ini"><?php } else { ?><span>Belum ada foto</span><?php } ?>
</div>
</div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
<?php if ($edit) { ?> <a class="btn-sekunder" href="siswa.php">Batal</a><?php } ?>
</form>
</div>

<form method="get" class="alat-bar">
<input type="search" class="form-control cari" name="cari" placeholder="Cari nama atau email" value="<?php echo e($cari); ?>" aria-label="Cari siswa">
<select class="form-control saring" name="status" aria-label="Saring status">
<option value="">Semua status</option>
<?php foreach(["Menunggu","Diterima","Ditolak"] as $s){ ?><option<?php echo $saring == $s ? " selected" : ""; ?>><?php echo $s; ?></option><?php } ?>
</select>
<button type="submit" class="btn-sekunder">Cari</button>
</form>
<p class="jumlah-hasil"><?php echo count($data); ?> siswa</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:900px">
<thead><tr><th>Foto</th><th>Siswa</th><th>Kelas</th><th>Cabang</th><th>Status</th><th>Aksi</th></tr></thead>
<tbody>
<?php foreach ($data as $s) { $f = url_foto($s["foto"]); ?>
<tr>
<td><?php if($f){ ?><img class="foto-kecil" src="<?php echo $f; ?>" alt="Pas foto <?php echo e($s["nama"]); ?>"><?php } else { ?><span class="foto-kecil" style="display:inline-block"></span><?php } ?></td>
<td class="nama"><?php echo e($s["nama"]); ?><span class="kecil"><?php echo e($s["email"]); ?> &middot; <?php echo e($s["no_hp"]); ?></span></td>
<td><?php echo e($s["nama_kelas"]); ?></td>
<td><?php echo e($s["nama_cabang"]); ?></td>
<td><span class="lencana <?php echo kelas_status($s["status"]); ?>"><?php echo e($s["status"]); ?></span></td>
<td class="aksi-baris">
<?php if($s["status"] != "Diterima"){ ?><form method="post" style="display:inline"><input type="hidden" name="id" value="<?php echo $s["id_siswa"]; ?>"><button type="submit" name="status" value="Diterima" class="tombol-kecil">Terima</button></form><?php } ?>
<?php if($s["status"] != "Ditolak"){ ?><form method="post" style="display:inline"><input type="hidden" name="id" value="<?php echo $s["id_siswa"]; ?>"><button type="submit" name="status" value="Ditolak" class="tombol-kecil hapus">Tolak</button></form><?php } ?>
<a class="tombol-kecil" href="siswa.php?edit=<?php echo $s["id_siswa"]; ?>#nama" style="text-decoration:none">Ubah</a>
<?php if($s["status"] == "Diterima"){ ?><a class="tombol-kecil" href="kartu.php?id=<?php echo $s["id_siswa"]; ?>" style="text-decoration:none">Kartu</a><?php } ?>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus siswa ini beserta akunnya?')"><button type="submit" name="hapus" value="<?php echo $s["id_siswa"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td>
</tr>
<?php } ?>
<?php if (!$data) { ?><tr><td colspan="6" class="kosong">Data tidak ditemukan.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<script>
var MAKS = 2 * 1024 * 1024;
var elFoto = document.getElementById("foto");
var kotak = document.getElementById("pratinjau");
var awal = kotak.innerHTML;
elFoto.addEventListener("change", function(){
var f = this.files[0]; var err = document.getElementById("err");
if(!f){ kotak.innerHTML = awal; return; }
if(["image/jpeg","image/png"].indexOf(f.type) < 0){ err.textContent = "Pas foto harus JPG atau PNG."; this.value = ""; kotak.innerHTML = awal; return; }
if(f.size > MAKS){ err.textContent = "Ukuran pas foto maksimal 2 MB."; this.value = ""; kotak.innerHTML = awal; return; }
err.textContent = "";
var r = new FileReader();
r.onload = function(ev){ kotak.innerHTML = ""; var im = document.createElement("img"); im.src = ev.target.result; im.alt = "Pratinjau pas foto"; kotak.appendChild(im); };
r.readAsDataURL(f);
});
function cek(f){
var err = document.getElementById("err");
if(f.nama.value.trim()=="" || f.alamat.value.trim()==""){ err.textContent="Nama dan alamat wajib diisi."; return false; }
if(f.tgl_lahir.value==""){ err.textContent="Tanggal lahir wajib diisi."; return false; }
if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email.value.trim())){ err.textContent="Format email tidak valid."; return false; }
if(!/^[0-9+]{8,15}$/.test(f.no_hp.value.trim())){ err.textContent="No HP harus 8-15 digit angka."; return false; }
if(f.id_kelas.value==""){ err.textContent="Pilih kelas."; return false; }
if(f.elements["id"].value=="0" && f.foto.files.length==0){ err.textContent="Pas foto wajib diunggah."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
