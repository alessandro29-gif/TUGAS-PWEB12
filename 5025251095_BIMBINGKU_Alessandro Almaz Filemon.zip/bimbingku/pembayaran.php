<?php
require_once "auth.php";
wajib_login(["admin", "admin_cabang"]);
$batas = id_cabang_batas();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["aksi"])) {
    $id = (int)$_POST["id"]; $aksi = $_POST["aksi"]; $cat = trim($_POST["catatan"] ?? "");
    $p = satu("SELECT p.*, k.id_cabang FROM pembayaran p JOIN kelas k ON k.id_kelas=p.id_kelas WHERE p.id_pembayaran=?", "i", [$id]);
    if ($p && (!$batas || $p["id_cabang"] == $batas) && in_array($aksi, ["Diterima", "Ditolak"])) {
        if ($aksi == "Ditolak" && $cat == "") {
            $_SESSION["pesan"] = "Isi catatan alasan penolakan terlebih dulu."; $_SESSION["pesan_galat"] = 1;
        } else {
            q("UPDATE pembayaran SET status=?, catatan=? WHERE id_pembayaran=?", "ssi", [$aksi, $cat, $id]);
            $_SESSION["pesan"] = "Pembayaran ditandai " . $aksi . ".";
        }
    }
    header("Location: pembayaran.php"); exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    $p = satu("SELECT p.*, k.id_cabang FROM pembayaran p JOIN kelas k ON k.id_kelas=p.id_kelas WHERE p.id_pembayaran=?", "i", [(int)$_POST["hapus"]]);
    if ($p && (!$batas || $p["id_cabang"] == $batas)) {
        q("DELETE FROM pembayaran WHERE id_pembayaran=?", "i", [$p["id_pembayaran"]]);
        $_SESSION["pesan"] = "Data pembayaran dihapus.";
    }
    header("Location: pembayaran.php"); exit;
}

$saring = $_GET["status"] ?? "";
$sql = "SELECT p.*, s.nama, k.nama_kelas, c.nama_cabang FROM pembayaran p JOIN siswa s ON s.id_siswa=p.id_siswa JOIN kelas k ON k.id_kelas=p.id_kelas JOIN cabang c ON c.id_cabang=k.id_cabang WHERE 1=1";
$tipe = ""; $par = [];
if ($batas) { $sql .= " AND k.id_cabang=?"; $tipe .= "i"; $par[] = $batas; }
if (in_array($saring, ["Menunggu", "Diterima", "Ditolak"])) { $sql .= " AND p.status=?"; $tipe .= "s"; $par[] = $saring; }
$data = semua($sql . " ORDER BY p.id_pembayaran DESC", $tipe, $par);
$total = 0; foreach ($data as $d) { if ($d["status"] == "Diterima") { $total += $d["jumlah"]; } }

$halaman = "pembayaran"; $judul_hero = "Verifikasi Pembayaran"; $teks_hero = "Periksa bukti transfer, lalu terima atau tolak.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<form method="get" class="alat-bar">
<select class="form-control saring" name="status" aria-label="Saring status">
<option value="">Semua status</option>
<?php foreach(["Menunggu","Diterima","Ditolak"] as $s){ ?><option<?php echo $saring == $s ? " selected" : ""; ?>><?php echo $s; ?></option><?php } ?>
</select>
<button type="submit" class="btn-sekunder">Saring</button>
<span class="total-tampil">Terverifikasi: <?php echo rupiah($total); ?></span>
</form>
<p class="jumlah-hasil"><?php echo count($data); ?> transaksi</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:960px">
<thead><tr><th>ID</th><th>Siswa</th><th>Kelas</th><th>Jumlah</th><th>Tanggal</th><th>Bukti</th><th>Status</th><th>Verifikasi</th></tr></thead>
<tbody>
<?php foreach ($data as $p) { ?>
<tr>
<td><?php echo $p["id_pembayaran"]; ?></td>
<td class="nama"><?php echo e($p["nama"]); ?><span class="kecil"><?php echo e($p["nama_cabang"]); ?></span></td>
<td><?php echo e($p["nama_kelas"]); ?></td>
<td class="angka-kanan"><?php echo rupiah($p["jumlah"]); ?></td>
<td><?php echo tgl($p["tanggal"]); ?></td>
<td><?php if ($p["bukti"] && is_file(__DIR__ . "/uploads/bukti/" . basename($p["bukti"]))) { ?><a href="uploads/bukti/<?php echo rawurlencode($p["bukti"]); ?>" target="_blank" rel="noopener">Lihat</a><?php } else { echo "-"; } ?></td>
<td><span class="lencana <?php echo kelas_status($p["status"]); ?>"><?php echo e($p["status"]); ?></span><?php if($p["catatan"]){ ?><span class="kecil"><?php echo e($p["catatan"]); ?></span><?php } ?></td>
<td class="aksi-baris">
<form method="post" style="display:inline-flex;gap:6px;align-items:center">
<input type="hidden" name="id" value="<?php echo $p["id_pembayaran"]; ?>">
<input class="form-control" name="catatan" placeholder="Catatan" aria-label="Catatan" style="width:120px;height:32px;font-size:13px;border-width:2px;padding:2px 10px">
<button type="submit" name="aksi" value="Diterima" class="tombol-kecil">Terima</button>
<button type="submit" name="aksi" value="Ditolak" class="tombol-kecil hapus">Tolak</button>
</form>
<form method="post" style="display:inline" onsubmit="return confirm('Hapus data pembayaran ini?')"><button type="submit" name="hapus" value="<?php echo $p["id_pembayaran"]; ?>" class="tombol-kecil hapus">Hapus</button></form>
</td>
</tr>
<?php } ?>
<?php if (!$data) { ?><tr><td colspan="8" class="kosong">Belum ada pembayaran.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<?php include "footer.php"; ?>
