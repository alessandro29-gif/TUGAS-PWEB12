<?php
session_start();
require_once "koneksi.php";

// $role boleh string atau array, kosong = cukup login
function wajib_login($role = []) {
    if (!isset($_SESSION["id_user"])) { header("Location: login.php"); exit; }
    $role = (array)$role;
    if ($role && !in_array($_SESSION["role"], $role)) { header("Location: index.php"); exit; }
}
function e($teks) { return htmlspecialchars((string)$teks, ENT_QUOTES, "UTF-8"); }
function rupiah($angka) { return "Rp " . number_format((int)$angka, 0, ",", "."); }
function tgl($d) { return $d ? date("d/m/Y", strtotime($d)) : "-"; }
function kelas_status($s) {
    if ($s == "Diterima" || $s == "Hadir" || $s == "aktif") return "lencana-diterima";
    if ($s == "Ditolak" || $s == "Alfa" || $s == "nonaktif") return "lencana-ditolak";
    return "lencana-menunggu";
}
function nama_role($r) {
    $p = ["admin" => "Admin Pusat", "admin_cabang" => "Admin Cabang", "pengajar" => "Pengajar", "siswa" => "Siswa"];
    return $p[$r] ?? $r;
}
// admin cabang hanya boleh melihat cabangnya sendiri
function id_cabang_batas() {
    return ($_SESSION["role"] == "admin_cabang") ? (int)$_SESSION["id_cabang"] : 0;
}

function q($sql, $tipe = "", $param = []) {
    global $koneksi;
    $st = mysqli_prepare($koneksi, $sql);
    if ($tipe != "") { mysqli_stmt_bind_param($st, $tipe, ...$param); }
    mysqli_stmt_execute($st);
    $hasil = mysqli_stmt_get_result($st);
    return $hasil === false ? $st : $hasil;
}
function semua($sql, $tipe = "", $param = []) {
    $r = q($sql, $tipe, $param);
    return mysqli_fetch_all($r, MYSQLI_ASSOC);
}
function satu($sql, $tipe = "", $param = []) {
    $r = q($sql, $tipe, $param);
    return mysqli_fetch_assoc($r);
}
function id_baru() {
    global $koneksi;
    return mysqli_insert_id($koneksi);
}

// Upload gambar (JPG/PNG, maks 2 MB). Kembalian: [nama_file, pesan_galat]
function simpan_gambar($kolom, $folder, $wajib = true) {
    if (!isset($_FILES[$kolom]) || $_FILES[$kolom]["error"] == UPLOAD_ERR_NO_FILE) {
        return $wajib ? [null, "Pas foto wajib diunggah."] : [null, ""];
    }
    $f = $_FILES[$kolom];
    if ($f["error"] != UPLOAD_ERR_OK) { return [null, "Upload gagal, coba lagi."]; }
    if ($f["size"] > 2 * 1024 * 1024) { return [null, "Ukuran file maksimal 2 MB."]; }
    $info = @getimagesize($f["tmp_name"]);
    $boleh = ["image/jpeg" => "jpg", "image/png" => "png"];
    if (!$info || !isset($boleh[$info["mime"]])) { return [null, "File harus berupa gambar JPG atau PNG."]; }
    $dir = __DIR__ . "/uploads/" . $folder . "/";
    if (!is_dir($dir)) { mkdir($dir, 0755, true); }
    $nama = time() . "_" . bin2hex(random_bytes(5)) . "." . $boleh[$info["mime"]];
    if (!move_uploaded_file($f["tmp_name"], $dir . $nama)) { return [null, "File gagal disimpan."]; }
    return [$nama, ""];
}
function hapus_berkas($folder, $nama) {
    $p = __DIR__ . "/uploads/" . $folder . "/" . basename((string)$nama);
    if ($nama && is_file($p)) { @unlink($p); }
}
function url_foto($nama) {
    $p = __DIR__ . "/uploads/foto/" . basename((string)$nama);
    return ($nama && is_file($p)) ? "uploads/foto/" . rawurlencode($nama) : "";
}

function id_pengajar_saya() {
    $p = satu("SELECT id_pengajar FROM pengajar WHERE id_user=?", "i", [$_SESSION["id_user"]]);
    return $p ? (int)$p["id_pengajar"] : 0;
}
function id_siswa_saya() {
    $s = satu("SELECT id_siswa FROM siswa WHERE id_user=?", "i", [$_SESSION["id_user"]]);
    return $s ? (int)$s["id_siswa"] : 0;
}
