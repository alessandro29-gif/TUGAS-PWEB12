<?php
require_once "auth.php";
if (isset($_SESSION["id_user"])) { header("Location: index.php"); exit; }
$galat = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    if ($email == "" || $password == "") {
        $galat = "Email dan password wajib diisi.";
    } else {
        $u = satu("SELECT * FROM user WHERE email = ?", "s", [$email]);
        if ($u && password_verify($password, $u["password"])) {
            if ($u["status"] != "aktif") {
                $galat = "Akun tidak aktif. Hubungi admin.";
            } else {
                session_regenerate_id(true);
                $_SESSION["id_user"] = $u["id_user"];
                $_SESSION["nama"] = $u["nama"];
                $_SESSION["role"] = $u["role"];
                $_SESSION["id_cabang"] = $u["id_cabang"];
                header("Location: index.php"); exit;
            }
        } else {
            $galat = "Email atau password salah.";
        }
    }
}
$halaman = "login";
$judul_hero = "Masuk";
$teks_hero = "Silakan login sesuai peranmu: admin, pengajar, atau siswa.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<div class="kartu-form kartu-login">
<?php if($galat != ""){ ?><div class="kotak-info galat" role="alert"><?php echo e($galat); ?></div><?php } ?>
<form method="post" novalidate onsubmit="return cek(this)">
<div class="form-group">
<label for="email">Email</label>
<input type="email" class="form-control" id="email" name="email" value="<?php echo e($_POST["email"] ?? ""); ?>" required autofocus>
</div>
<div class="form-group">
<label for="password">Password</label>
<input type="password" class="form-control" id="password" name="password" required>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" class="btn-utama">Masuk</button>
<a class="btn-sekunder" href="daftar.php">Daftar Siswa</a>
</form>
</div>
</div>
</section>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.email.value.trim()=="" || f.password.value==""){ err.textContent="Email dan password wajib diisi."; return false; }
return true;
}
</script>
<?php include "footer.php"; ?>
