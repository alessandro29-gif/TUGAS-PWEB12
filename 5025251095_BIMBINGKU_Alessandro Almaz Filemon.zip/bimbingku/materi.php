<?php
require_once "auth.php";
wajib_login();
$role = $_SESSION["role"]; $batas = id_cabang_batas();
$kelola = in_array($role, ["pengajar", "admin", "admin_cabang"]);

// kelas yang boleh dilihat/dikelola
if ($role == "pengajar") { $kelasku = semua("SELECT * FROM kelas WHERE id_pengajar=? ORDER BY nama_kelas", "i", [id_pengajar_saya()]); }
elseif ($role == "siswa") { $kelasku = semua("SELECT k.* FROM kelas k JOIN siswa s ON s.id_kelas=k.id_kelas WHERE s.id_user=? AND s.status='Diterima'", "i", [$_SESSION["id_user"]]); }
elseif ($batas) { $kelasku = semua("SELECT * FROM kelas WHERE id_cabang=? ORDER BY nama_kelas", "i", [$batas]); }
else { $kelasku = semua("SELECT * FROM kelas ORDER BY nama_kelas"); }
$ids = array_map("intval", array_column($kelasku, "id_kelas"));

if ($kelola && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["simpan"])) {
    $idk = (int)($_POST["id_kelas"] ?? 0); $judul = trim($_POST["judul"] ?? ""); $des = trim($_POST["deskripsi"] ?? ""); $url = trim($_POST["tautan"] ?? "");
    if (!in_array($idk, $ids) || $judul == "" || !preg_match('#^https?://#i', $url) || !filter_var($url, FILTER_VALIDATE_URL)) {
        $_SESSION["pesan"] = "Data tidak valid. Pilih kelas, isi judul, dan tautan harus diawali http:// atau https://.";
        $_SESSION["pesan_galat"] = 1;
    } else {
        q("INSERT INTO materi (id_kelas, judul, deskripsi, tautan, tgl_unggah) VALUES (?,?,?,?,CURDATE())", "isss", [$idk, $judul, $des, $url]);
        $_SESSION["pesan"] = "Materi berhasil ditambahkan.";
    }
    header("Location: materi.php"); exit;
}
if ($kelola && $_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["hapus"])) {
    $m = satu("SELECT id_kelas FROM materi WHERE id_materi=?", "i", [(int)$_POST["hapus"]]);
    if ($m && in_array((int)$m["id_kelas"], $ids)) { q("DELETE FROM materi WHERE id_materi=?", "i", [(int)$_POST["hapus"]]); $_SESSION["pesan"] = "Materi dihapus."; }
    header("Location: materi.php"); exit;
}
$data = $ids ? semua("SELECT m.*, k.nama_kelas FROM materi m JOIN kelas k ON k.id_kelas=m.id_kelas WHERE m.id_kelas IN (" . implode(",", $ids) . ") ORDER BY m.id_materi DESC") : [];

$halaman = "materi"; $judul_hero = "Materi Belajar"; $teks_hero = $kelola ? "Bagikan tautan materi (PDF, video, dokumen) per kelas." : "Materi dari kelas yang kamu ikuti.";
include "header.php";
?>
<section class="bagian">
<div class="container">
<?php if ($kelola) { ?>
<div class="kartu-form" style="margin-bottom:40px">
<h3 style="margin-top:0">Tambah Materi</h3>
<form method="post" novalidate onsubmit="return cek(this)">
<div class="row">
<div class="col-sm-4 form-group"><label for="id_kelas">Kelas</label><select class="form-control" id="id_kelas" name="id_kelas" required><option value="">-- Pilih kelas --</option>
<?php foreach($kelasku as $k){ ?><option value="<?php echo $k["id_kelas"]; ?>"><?php echo e($k["nama_kelas"]); ?></option><?php } ?></select></div>
<div class="col-sm-8 form-group"><label for="judul">Judul</label><input class="form-control" id="judul" name="judul" required></div>
</div>
<div class="row">
<div class="col-sm-6 form-group"><label for="tautan">Tautan materi</label><input type="url" class="form-control" id="tautan" name="tautan" placeholder="https://..." required></div>
<div class="col-sm-6 form-group"><label for="deskripsi">Deskripsi (opsional)</label><input class="form-control" id="deskripsi" name="deskripsi"></div>
</div>
<p class="pesan-error" id="err"></p>
<button type="submit" name="simpan" value="1" class="btn-utama">Simpan</button>
</form>
</div>
<?php } ?>
<p class="jumlah-hasil"><?php echo count($data); ?> materi</p>
<div class="tabel-bungkus table-responsive">
<table class="table tabel-anggota" style="min-width:640px">
<thead><tr><th>Judul</th><th>Kelas</th><th>Tanggal</th><th>Buka</th><?php if($kelola){ ?><th>Aksi</th><?php } ?></tr></thead>
<tbody>
<?php foreach ($data as $m) { ?>
<tr>
<td class="nama"><?php echo e($m["judul"]); ?><span class="kecil"><?php echo e($m["deskripsi"]); ?></span></td>
<td><?php echo e($m["nama_kelas"]); ?></td><td><?php echo tgl($m["tgl_unggah"]); ?></td>
<td><a href="<?php echo e($m["tautan"]); ?>" target="_blank" rel="noopener">Buka</a></td>
<?php if($kelola){ ?><td class="aksi-baris"><form method="post" style="display:inline" onsubmit="return confirm('Hapus materi ini?')"><button type="submit" name="hapus" value="<?php echo $m["id_materi"]; ?>" class="tombol-kecil hapus">Hapus</button></form></td><?php } ?>
</tr>
<?php } ?>
<?php if (!$data) { ?><tr><td colspan="5" class="kosong">Belum ada materi.</td></tr><?php } ?>
</tbody>
</table>
</div>
</div>
</section>
<?php if ($kelola) { ?>
<script>
function cek(f){
var err = document.getElementById("err");
if(f.id_kelas.value==""){ err.textContent="Pilih kelas."; return false; }
if(f.judul.value.trim()==""){ err.textContent="Judul wajib diisi."; return false; }
if(!/^https?:\/\/\S+$/i.test(f.tautan.value.trim())){ err.textContent="Tautan harus diawali http:// atau https://."; return false; }
return true;
}
</script>
<?php } ?>
<?php include "footer.php"; ?>
